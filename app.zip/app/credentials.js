
var credentials = {
      KEY: "token",
      ACCESS_TOKEN_URL: "https://jawbone.com/auth/oauth2/token",
      AUTHORIZATION_URL: "https://jawbone.com/auth/oauth2/auth",
      CLIENT_ID: "WtzakOFOnN4",
      CLIENT_SECRET: "a848a5c59d23b4174b6ac2a7001da1ff0b0bc603",
      REDIRECT_URL: "https://github.com/robots.txt",
      SCOPES: ['extended_read','sleep_read']
  };
